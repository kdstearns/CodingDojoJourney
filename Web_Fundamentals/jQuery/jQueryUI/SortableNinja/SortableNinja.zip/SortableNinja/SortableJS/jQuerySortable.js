$(document).ready(function(){
	$('.ui-sortable').sortable();
	
});