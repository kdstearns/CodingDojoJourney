$(document).ready(function(){
	$('#accordion').accordion();

	$(function(){
		$('#tabs').tabs();
	});
});